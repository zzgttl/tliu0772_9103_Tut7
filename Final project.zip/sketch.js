let flowers =[];
const numFlowers =4;


function initialiseFlowers() {
  // Clear the heads array
  // Note: only use this approach if nothing else is referencing the array
  flowers = []; 

  // Instantiate all the head objects with random values as outlined above
  for (let i = 0; i < numFlowers; i++) {
    let flower = new Flower(
      random(width), 
      random(height),
      Math. floor(random(6,7)),
      random(50, 150),
      color(random(360), 60, 100))
    flowers.push(flower); 
  }
}
function setup() {
  createCanvas(1000, 1000);
  colorMode(HSB);
  angleMode(DEGREES);
  initialiseFlowers();
  console.log(flowers)


}

function draw() {
  background(255);
  angleMode(DEGREES)
  for(const flower of flowers){
    console.log(flower)
    flower.display();
  }
}
