function drawflower(x,y,sc,leaveNumber){
  let LN = leaveNumber;
  let scale = sc;// for later
  strokeWeight(10);
  stroke(0)
  noFill();

  for (let e = 0;e<LN;e++){
    //curve function bit messy.
    //Problem 1 how to control the line better
    //Problem 2 currently not drawing into all directions
    curve(x+500*e, y-500*e,x, y, x+cos(e*45)*100, y+sin(e*75)*100, x, y)


  }
}

class Flower {

  // position,leavenumber, diameter and colour
  constructor(x, y, leaveNumber, diameter, colour) {
    this.x = x;
    this.y = y;
    this.leaveNumber = leaveNumber;
    this.diameter = diameter;
    this.colour = colour;
  }

  display() {

    strokeWeight(10);
    stroke(this.colour)
    noFill();
    for (let e = 0;e<this.leaveNumber;e++){

      curve(this.x+500*e, this.y-500*e,this.x, this.y, this.x+cos(e*45)*100, this.y+sin(e*75)*100, this.x, this.y)
      console.log(this.x,this.y)

  }


}
}